package lt.akademija.jpaexam.core;

public interface UniqueEntityWithAssociation extends UniqueEntity, EntityWithAssociation {
}
