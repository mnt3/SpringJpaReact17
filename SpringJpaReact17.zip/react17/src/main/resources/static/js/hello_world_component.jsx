
var HelloWorldComponent = React.createClass({
  render: function() {
    return (
      <div>Hello from React component</div>
    );
  }
});

window.HelloWorldComponent = HelloWorldComponent;
