package lt.itakademija.model.command;

/**
 * Created by mariusg on 2017.03.19.
 */
public final class UpdateContact {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
