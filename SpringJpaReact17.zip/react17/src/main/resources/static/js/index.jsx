var App = React.createClass({
  render: function() {
    return (
      <HelloWorldComponent />
    );
  }
});

ReactDOM.render(<App />, document.getElementById('root'));
