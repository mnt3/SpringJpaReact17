package lt.akademija.jpaexam.core;

public interface UniqueEntity {

    Long getId();
}
